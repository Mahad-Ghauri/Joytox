Future<bool> requestPermission() async {
  return true;
}
